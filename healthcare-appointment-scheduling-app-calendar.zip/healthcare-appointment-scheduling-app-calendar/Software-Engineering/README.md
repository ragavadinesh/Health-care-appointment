## Software Engineering Documents

- [User Stories](User_Stories.pdf)
- [StakeHolders And Their Views](Stakeholders&Views.pdf)
