create .env file and paste contents of env-info.txt 

npm install (installs all dependancies) \
npm start
